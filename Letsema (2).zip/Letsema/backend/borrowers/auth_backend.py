from django.contrib.auth.backends import ModelBackend
from borrowers.models import Borrower

class EmailBackend(ModelBackend):
    def authenticate(self, request, email=None, password=None, **kwargs):
        if email is None or password is None:
            return None  # Ensure None is returned for invalid input
        
        try:
            borrower = Borrower.objects.get(email=email)
            if borrower.check_password(password):
                return borrower
        except Borrower.DoesNotExist:
            return None
        return None  # Explicitly return None if authentication fails
