from rest_framework import viewsets, status
from rest_framework.response import Response
from datetime import datetime
from rest_framework.views import APIView
from django.contrib.auth import authenticate
from django.db import IntegrityError
from django.core.exceptions import ValidationError
from django.contrib.auth.password_validation import validate_password
from rest_framework_simplejwt.tokens import RefreshToken
from .models import Borrower, PaymentMethod
from .serializers import BorrowerSerializer, PaymentMethodSerializer

class BorrowerViewSet(viewsets.ModelViewSet):
    queryset = Borrower.objects.all()
    serializer_class = BorrowerSerializer

    def create(self, request, *args, **kwargs):
        data = request.data.copy()
        print("Raw input data:", data)  # Debugging
        
        required_fields = ['email', 'password', 'name', 'surname', 'dob', 'gender', 'idNumber', 'address']

        # Validate serializer
        serializer = self.get_serializer(data=data)
        if not serializer.is_valid():
            print("Serializer errors:", serializer.errors)
            return Response(
                {"detail": "Invalid data provided", "errors": serializer.errors},
                status=status.HTTP_400_BAD_REQUEST
            )

        try:
            # Create user - password will be hashed by create_user()
            borrower = Borrower.objects.create_user(
                email=data['email'].lower().strip(),
                password=data['password'],  # This gets hashed automatically
                name=data['name'],
                surname=data['surname'],
                dob=data['dob'],
                gender=data['gender'],
                idNumber=data['idNumber'],
                address=data['address']
            )
            
            # DEBUG: Verify password was hashed
            print(f"Password hash stored: {borrower.password[:50]}...")
            
            refresh = RefreshToken.for_user(borrower)
            return Response(
                {
                    "status": "success",
                    "borrower": serializer.data,
                    "tokens": {
                        "refresh": str(refresh),
                        "access": str(refresh.access_token),
                    }
                },
                status=status.HTTP_201_CREATED
            )
            
        except IntegrityError as e:
            error_detail = "Email already exists" if 'email' in str(e) else "ID number already exists"
            return Response(
                {"detail": error_detail},
                status=status.HTTP_400_BAD_REQUEST
            )

class PaymentMethodViewSet(viewsets.ModelViewSet):
    queryset = PaymentMethod.objects.all()
    serializer_class = PaymentMethodSerializer

    def get_queryset(self):
        return PaymentMethod.objects.filter(borrower=self.request.user)
    
    def create(self, request, *args, **kwargs):
        # Ensure the borrower is authenticated
        if not request.user.is_authenticated:
            return Response(
                {"detail": "Authentication credentials were not provided."},
                status=status.HTTP_401_UNAUTHORIZED
            )

        # Add the borrower to the request data
        request.data['borrower'] = request.user.id

        # Validate and save the data
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()

        # Return a success response
        return Response(serializer.data, status=status.HTTP_201_CREATED)

class BorrowerLoginView(APIView):
    def post(self, request, *args, **kwargs):
        email = request.data.get('email', '').lower().strip()
        password = request.data.get('password', '').strip()
        
        print(f"\nLogin attempt for: {email}")
        
        try:
            user = Borrower.objects.get(email=email)
            print(f"User found. Password check: {user.check_password(password)}")
            print(f"Stored password hash: {user.password[:50]}...")
            
            # Manual authentication fallback
            if user.check_password(password):
                refresh = RefreshToken.for_user(user)
                return Response({
                    'refresh': str(refresh),
                    'access': str(refresh.access_token),
                    'borrower': BorrowerSerializer(user).data
                })
                
        except Borrower.DoesNotExist:
            print("User not found in database")
        
        return Response(
            {'detail': 'Invalid email or password'},
            status=status.HTTP_401_UNAUTHORIZED
        )