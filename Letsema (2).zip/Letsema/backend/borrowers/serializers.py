from rest_framework import serializers
from .models import Borrower, PaymentMethod

class BorrowerSerializer(serializers.ModelSerializer):
    password = serializers.CharField(
        write_only=True,
        required=True,
        style={'input_type': 'password'},  # For browsable API
        trim_whitespace=False,
    )

    class Meta:
        model = Borrower
        fields = [
            'name',        # 1
            'surname',     # 2
            'email',       # 3
            'dob',         # 4
            'gender',      # 5
            'idNumber',    # 6
            'address',     # 7
            'password'     # 8
        ]
        extra_kwargs = {
            'password': {
                'write_only': True,
                'style': {'input_type': 'password'}
            },
        }

        
class PaymentMethodSerializer(serializers.ModelSerializer):
    class Meta:
        model = PaymentMethod
        fields = ['borrower', 'method_type', 'details', 'is_default']