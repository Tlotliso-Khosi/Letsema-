from django.db import models
from django.contrib.auth.models import AbstractUser

from django.contrib.auth.models import AbstractUser, BaseUserManager
from django.db import models


class BorrowerManager(BaseUserManager):
    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError("The Email field is required")
        
        email = self.normalize_email(email)
        borrower = self.model(email=email, **extra_fields)
        
        # Critical: This must be called before save()
        borrower.set_password(password)  
        
        borrower.save(using=self._db)
        return borrower
    """Custom manager for Borrower model using email authentication."""

    def create_superuser(self, email, password, **extra_fields):
        """Create and return a superuser with admin privileges."""
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)

        if extra_fields.get("is_staff") is not True:
            raise ValueError("Superuser must have is_staff=True.")
        if extra_fields.get("is_superuser") is not True:
            raise ValueError("Superuser must have is_superuser=True.")

        return self.create_user(email, password, **extra_fields)


from django.contrib.auth.models import AbstractUser
from django.db import models

class Borrower(AbstractUser):
    # Remove username field (we'll use email instead)
    username = None  
    email = models.EmailField(unique=True)  # Make email the login field
    
    # Your custom fields
    name = models.CharField(max_length=100)
    surname = models.CharField(max_length=100)
    dob = models.DateField()
    gender = models.CharField(max_length=10)
    idNumber = models.CharField(max_length=20, unique=True)
    address = models.CharField(max_length=255)
    credit_score = models.IntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    # Set email as the USERNAME_FIELD (replaces username)
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['name', 'surname']  # Fields for createsuperuser

    objects = BorrowerManager()  # THIS IS CRUCIAL

    def __str__(self):
        return f"{self.name} {self.surname}"


class PaymentMethod(models.Model):
    borrower = models.ForeignKey(Borrower, on_delete=models.CASCADE, related_name='payment_methods')
    method_type = models.CharField(max_length=50)  # e.g., Bank, Mobile Money
    details = models.JSONField()  # Store payment method details (e.g., account number, phone number)

    def __str__(self):
        return f"{self.method_type} - {self.borrower.name}"