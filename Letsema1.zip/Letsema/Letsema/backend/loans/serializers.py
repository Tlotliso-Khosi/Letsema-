from rest_framework import serializers
from .models import Loan
from mfi.models import MFI
from borrowers.models import Borrower
from borrowers.serializers import BorrowerSerializer


class LoanSerializer(serializers.ModelSerializer):
    borrower = serializers.PrimaryKeyRelatedField(
        queryset=Borrower.objects.all(),
        required=False  # Not required because we set it automatically
    )
    
    class Meta:
        model = Loan
        fields = [
            'mfi',
            'amount',
            'payment_method',
            'netpay',
            'borrower'
        ]
        extra_kwargs = {
            'netpay': {'required': False},
            'borrower': {'required': False},
            'mfi': {'required': False}
        }

    def validate_mfi_name(self, value):
        try:
            return MFI.objects.get(name=value)
        except MFI.DoesNotExist:
            raise serializers.ValidationError("MFI with this name does not exist")
        


class LoanDisplaySerializer(serializers.ModelSerializer):
    """
    Read-only serializer specifically for MFI dashboard display
    Doesn't affect your existing LoanSerializer
    """
    borrower = BorrowerSerializer(read_only=True)
    mfi_name = serializers.CharField(source='mfi.name', read_only=True)
    
    class Meta:
        model = Loan
        fields = [
            'id',
            'borrower',
            'mfi_name',
            'amount',
            'payment_method',
            'netpay',
            'status',
            'application_date',
        ]
        read_only_fields = fields  # All fields are read-only


class BorrowerLoanDisplaySerializer(serializers.ModelSerializer):
    """
    Read-only serializer specifically for MFI dashboard display
    Doesn't affect your existing LoanSerializer
    """
    borrower = BorrowerSerializer(read_only=True)
    mfi_name = serializers.CharField(source='mfi.name', read_only=True)
    
    class Meta:
        model = Loan
        fields = [
            'id',
            'borrower',
            'mfi_name',
            'amount',
            'payment_method',
            'status',
            'amount_due',
            'interest_rate',
            'application_date',
        ]
        read_only_fields = fields  # All fields are read-only


class LoanRepaymentSerializer(serializers.Serializer):
    # Define fields as class attributes (not in Meta)
    loan_id = serializers.IntegerField(required=True)
    amount = serializers.DecimalField(
        max_digits=12, 
        decimal_places=2,
        required=True,
        min_value=0.01  # Ensure positive amount
    )
    payment_method = serializers.CharField(
        max_length=50,
        required=True
    )

    # Meta class is only used with ModelSerializer
    # Remove the Meta class completely

    def validate_loan_id(self, value):
        """Verify loan exists"""
        if not Loan.objects.filter(id=value).exists():
            raise serializers.ValidationError("Loan does not exist")
        return value

    def validate(self, data):
        """Additional validation"""
        if data['amount'] <= 0:
            raise serializers.ValidationError({
                'amount': 'Amount must be positive'
            })
        return data        
              