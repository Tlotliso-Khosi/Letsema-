from rest_framework import viewsets, status
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.exceptions import ValidationError,PermissionDenied
from rest_framework.views import APIView
from .models import Loan
from mfi.models import MFI
from borrowers.models import Borrower
from transactions.models import Transaction
from .serializers import LoanSerializer,LoanDisplaySerializer, LoanRepaymentSerializer
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404
from rest_framework.decorators import action
from rest_framework import viewsets, permissions, status
from rest_framework.response import Response



class LoanApplicationViewSet(viewsets.ModelViewSet):
    serializer_class = LoanSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        user = self.request.user
        if isinstance(user, Borrower):
            return Loan.objects.filter(borrower=user)
        elif hasattr(user, 'mfi'):
            return Loan.objects.filter(mfi=user.mfi)
        return Loan.objects.none()

    def create(self, request, *args, **kwargs):
        data = request.data.copy()
        user = request.user

        print("\n=== USER VERIFICATION ===")
        print(f"User ID: {user.id}")
        print(f"User Type: {user.__class__.__name__}")
        
        # Convert MFI name to ID if provided
        if 'mfi' in data:
            try:
                mfi = MFI.objects.get(name=data['mfi'])
                data['mfi'] = mfi.id
                print(f"Converted MFI '{data['mfi']}' to ID: {mfi.id}")
            except MFI.DoesNotExist:
                return Response({
                    'success': False,
                    'error': 'mfi_not_found',
                    'message': 'The specified MFI does not exist'
                }, status=status.HTTP_400_BAD_REQUEST)

        # DIRECT BORROWER ASSIGNMENT
        if isinstance(user, Borrower):
            data['borrower'] = user.id
            print(f"Auto-assigned borrower ID: {user.id}")
        elif hasattr(user, 'mfi') and 'borrower' not in data:
            return Response({
                'success': False,
                'error': 'borrower_required',
                'message': 'MFI must specify a borrower'
            }, status=status.HTTP_400_BAD_REQUEST)

        print("\n=== FINAL REQUEST DATA ===")
        print(data)

        serializer = self.get_serializer(data=data)
        serializer.context['request'] = request  # Pass request to serializer
        
        try:
            serializer.is_valid(raise_exception=True)
            loan = serializer.save()
            
            print("\n=== LOAN CREATION SUCCESS ===")
            print(f"Created Loan ID: {loan.id}")
            print(f"Borrower ID: {loan.borrower_id}")
            print(f"MFI ID: {loan.mfi_id}")
            
            return Response({
                'success': True,
                'data': serializer.data,
                'message': 'Loan created successfully'
            }, status=status.HTTP_201_CREATED)
            
        except ValidationError as e:
            print("\n=== VALIDATION FAILED ===")
            print(f"Errors: {e.detail}")
            return Response({
                'success': False,
                'error': 'validation_error',
                'message': 'Invalid data provided',
                'details': e.detail
            }, status=status.HTTP_400_BAD_REQUEST)
        
    @action(detail=True, methods=['post'])
    def approve(self, request, pk=None):
        """Approve a loan application"""
        return self._update_status(pk, 'APPROVED')

    @action(detail=True, methods=['post'])
    def reject(self, request, pk=None):
        """Reject a loan application"""
        return self._update_status(pk, 'REJECTED')

    def _update_status(self, pk, status):
        """Shared method for status updates"""
        loan = get_object_or_404(Loan, pk=pk)
        
        try:
            # Get MFI from user
            mfi = MFI.objects.get(pk=self.request.user.pk)
            if loan.mfi != mfi:
                raise PermissionDenied("You can only update your MFI's loans")
            
            loan.status = status
            loan.save()
            
            return Response({
                'status': 'success',
                'loan_id': loan.id,
                'new_status': status,
                'message': f'Loan {status.lower()} successfully'
            })
            
        except MFI.DoesNotExist:
            raise PermissionDenied("Only MFI users can update loan status")

#Business Analytics
class LoanSearchViewSet(viewsets.ReadOnlyModelViewSet):
    """
    Loan search endpoint (all loans with access control)
    GET /api/loans/ - List all visible loans
    GET /api/loans/{id}/ - Get specific loan details
    """
    serializer_class = LoanDisplaySerializer
    permission_classes = [permissions.IsAuthenticated]
    queryset = Loan.objects.all()

    def get_queryset(self):
        user = self.request.user
        
        # Superusers see all loans
        if user.is_superuser:
            return self.queryset.select_related('borrower', 'mfi')
            
        # MFIs see their own loans
        try:
            mfi = MFI.objects.get(pk=user.pk)
            return self.queryset.filter(mfi=mfi).select_related('borrower')
        except MFI.DoesNotExist:
            pass
            
        # Borrowers see their own loans
        if isinstance(user, Borrower):
            return self.queryset.filter(borrower=user).select_related('mfi')
            
        return self.queryset.none()

    def retrieve(self, request, *args, **kwargs):
        """Get any loan (with permission check)"""
        loan = get_object_or_404(Loan, pk=kwargs['pk'])
        user = request.user

        # Access control checks
        if user.is_superuser:
            pass  # Admins can see everything
        elif hasattr(user, 'mfi') and loan.mfi != user.mfi:
            raise PermissionDenied("You can only view your MFI's loans")
        elif isinstance(user, Borrower) and loan.borrower != user:
            raise PermissionDenied("You can only view your own loans")

        serializer = self.get_serializer(loan)
        return Response(serializer.data)
    

class LoanRepaymentView(APIView):
    permission_classes = [IsAuthenticated]
    
    def post(self, request):
        print("\n=== Received repayment request ===")
        print(f"User: {request.user.email} (ID: {request.user.id})")
        print(f"Raw data: {request.data}")  # Print raw incoming data

        serializer = LoanRepaymentSerializer(data=request.data)
        if not serializer.is_valid():
            print("\n! Validation errors:", serializer.errors)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        loan_id = serializer.validated_data['loan_id']
        amount = serializer.validated_data['amount']
        payment_method = serializer.validated_data['payment_method']

        print(f"\nProcessing payment for loan {loan_id}:")
        print(f"Amount: {amount}, Method: {payment_method}")

        try:
            loan = get_object_or_404(Loan, id=loan_id)
            print(f"Found loan (Status: {loan.status}, Borrower: {loan.borrower.email})")
            
            # Ownership check
            if loan.borrower != request.user:
                print("! Ownership violation - user doesn't match loan borrower")
                return Response(
                    {"detail": "You can only repay your own loans"},
                    status=status.HTTP_403_FORBIDDEN
                )
            
            # Status check
            if loan.status not in ['APPROVED', 'DISBURSED']:
                print(f"! Invalid loan status: {loan.status}")
                return Response(
                    {"detail": "This loan is not in a repayable state"},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            # Amount validation
            if amount <= 0:
                print("! Invalid amount (<= 0)")
                return Response(
                    {"detail": "Payment amount must be positive"},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            # Payment method validation
            if payment_method != loan.payment_method:
                print(f"! Payment method mismatch (Loan: {loan.payment_method}, Provided: {payment_method})")
                return Response(
                    {
                        "detail": f"This loan requires {loan.get_payment_method_display()} payments",
                        "required_method": loan.payment_method,
                        "provided_method": payment_method
                    },
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            # Process payment
            print(f"\nProcessing payment (Current due: {loan.amount_due})")
            loan.amount_due -= amount
            if loan.amount_due <= 0:
                loan.status = 'REPAID'
                print("Loan fully repaid!")
            
            # Create transaction record
            transaction = Transaction.objects.create(
                loan=loan,
                mfi=loan.mfi,
                borrower=request.user,
                amount=amount,
                payment_method=payment_method
            )
            print(f"Created transaction ID: {transaction.id}")
            loan.save()
            
            print("Payment successful!")
            return Response({
                "status": "success",
                "loan_id": loan.id,
                "amount_paid": str(amount),
                "remaining_balance": str(loan.amount_due),
                "new_status": loan.status,
                "payment_method": payment_method,
                "transaction_id": transaction.id
            })
            
        except Exception as e:
            print(f"\n! ERROR: {str(e)}")
            return Response(
                {"detail": "Payment processing failed"},
                status=status.HTTP_400_BAD_REQUEST
            )