from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.contrib.auth.models import Group, Permission

class MFIManager(BaseUserManager):
    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError('The Email field must be set')
        email = self.normalize_email(email).lower()
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        return self.create_user(email, password, **extra_fields)

class MFI(AbstractBaseUser):
    username = None  # We're using email as the username
    name = models.CharField(max_length=255)
    interest_rate = models.DecimalField(max_digits=5, decimal_places=2, default=0.10)
    licenseID = models.CharField(max_length=50, unique=True)
    email = models.EmailField(unique=True)
    created_at = models.DateTimeField(auto_now_add=True)

    objects = MFIManager()

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['name', 'license_ID']

    def __str__(self):
        return self.name