from rest_framework import serializers
from .models import MFI

class MFISerializer(serializers.ModelSerializer):
    password = serializers.CharField(
        write_only=True,
        required=True,
    )

    class Meta:
        model = MFI
        fields = [
            'name', 
            'interest_rate',
            'licenseID',
            'email',
            'password',
        ]
        extra_kwargs = {
            'password': {
                'write_only': True,
            }
        }