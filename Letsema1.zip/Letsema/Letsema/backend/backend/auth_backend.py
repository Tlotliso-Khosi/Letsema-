from django.contrib.auth.backends import ModelBackend
from django.contrib.auth import get_user_model
from django.db.models import Q
from mfi.models import MFI

class MultiModelAuthBackend(ModelBackend):
    def authenticate(self, request, username=None, password=None, **kwargs):
        UserModel = get_user_model()
        
        # Try MFI first since it's more specific
        try:
            mfi = MFI.objects.get(Q(email__iexact=username))
            if mfi.check_password(password):
                # Add an explicit marker
                mfi.is_mfi_user = True
                return mfi
        except MFI.DoesNotExist:
            pass
        
        # Then try Borrower
        try:
            user = UserModel.objects.get(Q(email__iexact=username))
            if user.check_password(password):
                user.is_mfi_user = False
                return user
        except UserModel.DoesNotExist:
            return None
        
        return None

    def get_user(self, user_id):
        # First try to get as MFI
        try:
            mfi = MFI.objects.get(pk=user_id)
            mfi.is_mfi_user = True
            return mfi
        except MFI.DoesNotExist:
            pass
        
        # Then try as Borrower
        UserModel = get_user_model()
        try:
            user = UserModel.objects.get(pk=user_id)
            user.is_mfi_user = False
            return user
        except UserModel.DoesNotExist:
            return None