# serializers.py
from rest_framework import serializers
from .models import Transaction

class TransactionSerializer(serializers.ModelSerializer):
    loan_id = serializers.IntegerField(source='loan.id', read_only=True)
    mfi_name = serializers.CharField(source='mfi.name', read_only=True)
    payment_method_display = serializers.CharField(source='get_payment_method_display', read_only=True)

    class Meta:
        model = Transaction
        fields = [
            'loan_id',
            'mfi_name',
            'amount',
            'payment_method',
            'payment_method_display',
            'timestamp',
            'Type'
        ]
        read_only_fields = fields