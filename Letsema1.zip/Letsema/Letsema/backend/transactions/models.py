from django.db import models
from borrowers.models import Borrower
from mfi.models import MFI
from rest_framework.exceptions import ValidationError
from django.core.validators import MinValueValidator
from django.db import models
from decimal import Decimal
from borrowers.models import Borrower
from mfi.models import MFI
from loans.models import Loan
from rest_framework.exceptions import ValidationError


class Transaction(models.Model):

    TYPE_CHOICES = [
        ('REPAYMENT', 'Repayment'),
        ('DISBURSEMENT', 'Disbursement'),
        ('PAYMENT', 'Payment'),  # Kept for backward compatibility
    ]

    loan = models.ForeignKey(Loan,on_delete=models.CASCADE,null=True,blank=True,related_name='transactions')
    mfi = models.ForeignKey(MFI,on_delete=models.CASCADE,null=True,blank=True,related_name='transactions')
    borrower = models.ForeignKey(Borrower,on_delete=models.CASCADE,null=True,blank=True,related_name='transactions')
    amount = models.DecimalField(max_digits=12,decimal_places=2, validators=[MinValueValidator(Decimal('0.01'))])
    payment_method = models.CharField(max_length=50)
    timestamp = models.DateTimeField(auto_now_add=True)
    Type = models.CharField(max_length=50, choices=TYPE_CHOICES, default='REPAYMENT')

    def __str__(self):
        return f"Transaction #{self.transaction_id} - {self.amount} - {self.payment_method}"

    def clean(self):
        """Validate the transaction before saving"""
        if self.amount <= 0:
            raise ValidationError("Transaction amount must be positive")
        
        # Auto-populate relationships if not set
        if self.loan and not self.mfi:
            self.mfi = self.loan.mfi
        if self.loan and not self.borrower:
            self.borrower = self.loan.borrower

    def save(self, *args, **kwargs):
        """Custom save logic"""
        self.clean()  # Run validation
        super().save(*args, **kwargs)