# views.py
from rest_framework import generics, permissions
from .models import Transaction
from .serializers import TransactionSerializer

class UserTransactionsView(generics.ListAPIView):
    """
    GET /api/transactions/
    Returns filtered transactions for the authenticated borrower
    Simple filtering via query parameters:
    - ?loan_id=1
    - ?payment_method=MOBILE_MONEY
    """
    serializer_class = TransactionSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        queryset = Transaction.objects.filter(
            borrower=self.request.user
        ).select_related('mfi', 'loan').order_by('-timestamp')

        # Simple manual filtering
        loan_id = self.request.query_params.get('loan_id')
        if loan_id:
            queryset = queryset.filter(loan_id=loan_id)

        payment_method = self.request.query_params.get('payment_method')
        if payment_method:
            queryset = queryset.filter(payment_method=payment_method)

        return queryset