from django.contrib import admin
from django.urls import path, include
from django.http import JsonResponse
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView

# Default Home View
def home_view(request):
    return JsonResponse({"message": "Welcome to the API. Use /api/ to access endpoints."})

urlpatterns = [
    path('', home_view),  # Home view to prevent 404 error
    path('admin/', admin.site.urls),  # Django admin
    path('api/borrowers/', include('borrowers.urls')),  # Borrowers app
    path('api/loans/', include('loans.urls')),
    path('api/mfi/', include('mfi.urls')),
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),  # JWT token obtain pair
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),  # JWT token refresh
]
