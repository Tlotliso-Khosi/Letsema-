from django.db import models
from borrowers.models import Borrower
from mfi.models import MFI
from rest_framework.exceptions import ValidationError

class Loan(models.Model):
    
    LOAN_STATUS_CHOICES = [
        ('PENDING', 'Pending'),
        ('APPROVED', 'Approved'),
        ('REJECTED', 'Rejected'),
        ('DISBURSED', 'Disbursed'),
        ('REPAID', 'Repaid'),
    ]
    
    borrower = models.ForeignKey(Borrower, on_delete=models.CASCADE,null= True,blank=True, related_name='loan_applications')
    mfi = models.ForeignKey(MFI, on_delete=models.CASCADE,null=True,blank=True, related_name='loan_applications')
    #mfi = models.CharField(max_length= 50)
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    interest_rate = models.DecimalField(max_digits=5, decimal_places=2, blank=True)  # Will be auto-filled
    #payment_method = models.ForeignKey(PaymentMethod, on_delete=models.SET_NULL, null=True, related_name='loan_payment_method')
    payment_method = models.CharField(max_length=50)
    status = models.CharField(max_length=20, choices=LOAN_STATUS_CHOICES, default='PENDING')
    application_date = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now_add=True)
    approved_date = models.DateTimeField(null=True, blank=True)
    amount_due = models.DecimalField(max_digits=12, decimal_places=2, blank=True)  # Will be auto-calculated
    netpay = models.DecimalField(max_digits=12, decimal_places=2)

    def __str__(self):
        return f"Loan #{self.id} - {self.borrower.name} - {self.amount}"
    
    def clean(self):
        if self.status in ['APPROVED', 'DISBURSED'] and not self.borrower:
            raise ValidationError("Loan must have a borrower before approval/disbursement")
    
    def save(self, *args, **kwargs):
        # Get interest rate from MFI if not set
        if not self.interest_rate and self.mfi:
            self.interest_rate = self.mfi.interest_rate

        # Calculate amount due (principal + interest)
        if self.amount and self.interest_rate:
            interest_amount = self.amount * self.interest_rate
            self.amount_due = self.amount + interest_amount

        super().save(*args, **kwargs)
