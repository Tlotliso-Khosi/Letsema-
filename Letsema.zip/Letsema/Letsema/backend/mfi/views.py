from rest_framework import viewsets, status, permissions
from rest_framework.response import Response
from rest_framework_simplejwt.tokens import RefreshToken
from .models import MFI
from loans.models import Loan
from .serializers import MFISerializer
from loans.serializers import LoanDisplaySerializer
from django.db import IntegrityError
from rest_framework.views import APIView
from rest_framework.exceptions import PermissionDenied
from rest_framework.permissions import AllowAny,IsAuthenticated
from django.contrib.auth import authenticate
from mfi.models import MFI
from rest_framework.decorators import action
from django.shortcuts import get_object_or_404

class MFIViewSet(viewsets.ModelViewSet):
    queryset = MFI.objects.all()
    serializer_class = MFISerializer

    def create(self, request, *args, **kwargs):
        print("\n=== DEBUG START ===")
        print("1. Raw request data received:")
        print(request.data)

        data = request.data.copy()

        required_fields =['name', 'interest_rate','licenseID','email', 'password']

        #Validate serializer
        serializer = self.get_serializer(data=request.data)
        is_valid = serializer.is_valid()
        print("\n3. Validation result:", is_valid)
        
        if not is_valid:
            print("\n4. Validation errors:")
            print(serializer.errors)
            print("=== DEBUG END ===")
            return Response(
                {
                    'success': False,
                    'message': 'Validation failed',
                    'errors': serializer.errors
                },
                status=status.HTTP_400_BAD_REQUEST
            )

        try:
            validated_data = serializer.validated_data

            # Create MFI instance
            mfi = MFI.objects.create_user(
                name= validated_data['name'],
                email=validated_data['email'].lower().strip(),
                interest_rate = validated_data['interest_rate'],
                licenseID = validated_data['licenseID'],
                password = validated_data['password']
            )
            print("\n6. MFI created successfully:")
            print(f"ID: {mfi.id}, Email: {mfi.email}, Name: {mfi.name}")
            
            # Generate JWT tokens
            refresh = RefreshToken.for_user(mfi)
            access_token = str(refresh.access_token)
            refresh_token = str(refresh)
            print("\n7. Tokens generated successfully")
            
            return Response(
                {
                    "status": "success",
                    "mfi": serializer.data,
                    "token":{ 
                        "refresh": str(refresh),
                        "access": str(refresh.access_token),
                    }
                },  
                status=status.HTTP_201_CREATED
            )
            
        except IntegrityError as e:
            error_detail = "Email already exist" if "email" in str(e) else "ID number already exxists"
            return Response(
                {"detail": error_detail},
                status=status.HTTP_400_BAD_REQUEST
            )
       
# mfi/views.py
class MFILoginView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        email = request.data.get('email', '').lower().strip()
        password = request.data.get('password', '').strip()

        # Use Django's authenticate function which will use our custom backend
        user = authenticate(request, username=email, password=password)
        
        if user and isinstance(user, MFI):  # Verify it's an MFI user
            refresh = RefreshToken.for_user(user)
            return Response({
                'refresh': str(refresh),
                'access': str(refresh.access_token),
                'mfi': MFISerializer(user).data
            })
        
        return Response(
            {'detail': 'Invalid credentials'},
            status=status.HTTP_401_UNAUTHORIZED
        )
    
class MFILoanRequestViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = LoanDisplaySerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        try:
            mfi = MFI.objects.get(pk=self.request.user.pk)
            return Loan.objects.filter(
                mfi=mfi,
                status='PENDING'
            ).select_related('borrower', 'mfi').order_by('-application_date')
        except MFI.DoesNotExist:
            return Loan.objects.none()
    
    def retrieve(self, request, *args, **kwargs):
        """
        GET /api/mfi/loan-requests/{loan_id}/
        Returns loan details if MFI owns it (regardless of status)
        """
        try:
            # Get the loan instance
            loan = get_object_or_404(Loan, pk=kwargs['pk'])
            
            # Verify MFI ownership
            mfi = MFI.objects.get(pk=request.user.pk)
            if loan.mfi != mfi:
                raise PermissionDenied("You can only view your MFI's loans")
            
            serializer = self.get_serializer(loan)
            return Response(serializer.data)
            
        except MFI.DoesNotExist:
            raise PermissionDenied("Only MFI users can view loan details")
        
    
class MFIActiveLoansViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = LoanDisplaySerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        try:
            mfi = MFI.objects.get(pk=self.request.user.pk)
            return Loan.objects.filter(
                mfi=mfi,
                status='APPROVED'
            ).select_related('borrower', 'mfi').order_by('-application_date')
        except MFI.DoesNotExist:
            return Loan.objects.none()
        
    