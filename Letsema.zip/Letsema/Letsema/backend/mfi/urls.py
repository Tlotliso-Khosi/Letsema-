from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import MFIViewSet,MFILoginView,MFILoanRequestViewSet,MFIActiveLoansViewSet

router = DefaultRouter()
router.register(r'register', MFIViewSet, basename='mfi')
router.register(r'loan-requests', MFILoanRequestViewSet, basename='mfi-loan-requests')
router.register(r'active-loans', MFIActiveLoansViewSet, basename='mfi-active-loans')


urlpatterns = [
    path('', include(router.urls)),
    path('login/',MFILoginView.as_view(), name='mfi-login' )
]