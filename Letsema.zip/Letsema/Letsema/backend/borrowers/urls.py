from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import BorrowerViewSet, PaymentMethodViewSet, BorrowerLoginView

router = DefaultRouter()
router.register(r'payment-methods', PaymentMethodViewSet)  # Keep payment methods in the router

urlpatterns = [
    # Custom URL for creating a borrower
    path('register/', BorrowerViewSet.as_view({'post': 'create'}), name='borrower-register'),
    # Include the router URLs (for payment methods)
    path('', include(router.urls)),
    # Borrower login URL
    path('login/', BorrowerLoginView.as_view(), name='borrower-login'),
]